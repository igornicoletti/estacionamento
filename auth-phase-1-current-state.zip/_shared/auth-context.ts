import { createAdminClient } from "./auth-supabase-admin.ts"

type SupabaseAdminClient = ReturnType<typeof createAdminClient>

function decodeJwtPayload(token: string): Record<string, unknown> | null {
  const parts = token.split(".")

  if (parts.length !== 3) {
    return null
  }

  try {
    const base64 = parts[1].replace(/-/g, "+").replace(/_/g, "/")
    const padded = base64 + "=".repeat((4 - (base64.length % 4)) % 4)

    return JSON.parse(atob(padded)) as Record<string, unknown>
  } catch {
    return null
  }
}

export async function getAuthenticatedActor(req: Request) {
  const authorization = req.headers.get("authorization")

  if (!authorization) {
    return null
  }

  const token = authorization.replace(/^Bearer\s+/i, "")
  const supabase = createAdminClient()
  const { data, error } = await supabase.auth.getUser(token)

  if (error || !data.user) {
    return null
  }

  // Reject tokens whose underlying session row was revoked (e.g. by an
  // admin action), even if the JWT itself has not expired yet.
  const payload = decodeJwtPayload(token)
  const sessionId =
    payload && typeof payload.session_id === "string"
      ? payload.session_id
      : null

  if (sessionId) {
    const { data: isActive, error: sessionError } = await supabase.rpc(
      "is_auth_session_active",
      { p_session_id: sessionId }
    )

    if (sessionError) {
      console.error("auth_session_lookup_failed", {
        error: sessionError.message,
      })
      return null
    }

    if (isActive !== true) {
      return null
    }
  }

  const { data: profile } = await supabase
    .from("app_users")
    .select("id, auth_user_id, name, role, status")
    .eq("auth_user_id", data.user.id)
    .maybeSingle()

  if (!profile) {
    return null
  }

  return {
    authUserId: data.user.id,
    id: String(profile.id),
    name: String(profile.name),
    role: String(profile.role),
    status: String(profile.status),
  }
}

export type AuthenticatedActor =
  NonNullable<Awaited<ReturnType<typeof getAuthenticatedActor>>>

export async function actorHasPermission(
  actor: Awaited<ReturnType<typeof getAuthenticatedActor>>,
  permissionKey: string,
  supabase: SupabaseAdminClient = createAdminClient()
) {
  if (!actor || actor.status !== "active") {
    return false
  }

  const appPermissionResponse = await supabase
    .from("app_role_permissions")
    .select("permission_key")
    .eq("role_key", actor.role)
    .in("permission_key", [permissionKey, "*"])
    .limit(1)

  if (!appPermissionResponse.error && (appPermissionResponse.data ?? []).length > 0) {
    return true
  }

  if (appPermissionResponse.error) {
    console.error("app_permission_lookup_failed", {
      permissionKey,
      role: actor.role,
      error: appPermissionResponse.error.message,
    })
  }

  return false
}

export async function requirePermissionActor(
  actor: Awaited<ReturnType<typeof getAuthenticatedActor>>,
  permissionKey: string,
  supabase: SupabaseAdminClient = createAdminClient()
) {
  if (!actor || actor.status !== "active") {
    throw new Error("Unauthorized")
  }

  if (!(await actorHasPermission(actor, permissionKey, supabase))) {
    throw new Error("Forbidden")
  }

  return actor
}

export function requireAdminActor(actor: Awaited<ReturnType<typeof getAuthenticatedActor>>) {
  if (!actor || actor.status !== "active") {
    throw new Error("Unauthorized")
  }

  if (actor.role !== "owner" && actor.role !== "admin") {
    throw new Error("Forbidden")
  }

  return actor
}
